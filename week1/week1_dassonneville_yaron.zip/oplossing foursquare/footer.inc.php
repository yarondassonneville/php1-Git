<footer background-color="blue">

</footer>