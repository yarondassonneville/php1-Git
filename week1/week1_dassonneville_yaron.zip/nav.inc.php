<nav>
        <h1>Logo</h1>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="blog.php">Blog</a></li>
        </ul>
</nav>